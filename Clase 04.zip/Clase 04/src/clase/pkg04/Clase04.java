/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase.pkg04;

/**
 *
 * @author alumno
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //String es una clase
        String nombre = "marcela";
        System.out.println("marcela");
        // Pasar texto a mayusculas
        nombre.toUpperCase();
        System.out.println(nombre.toUpperCase());
        
        nombre = nombre.toUpperCase();
        System.out.println("nombre");
        
        //Pasar a minuscula
        System.out.println(nombre.toLowerCase());
        System.out.println(nombre);
        nombre = nombre.toLowerCase();
        System.out.println(nombre);
        
        String palabra1 = "cuesta";
        System.out.println("cuesta");
        String palabra2 = "subir";
        System.out.println("subir");
        String palabra3 = "la";
        System.out.println("la");
        String palabra4 = "a";
        System.out.println("a");
        String palabra5 = "e";
        System.out.println("e");
        String palabra6 = "l";
        System.out.println("l");
        String palabra7 = "v";
        System.out.println("v");
        String palabra8 = "s";
        System.out.println("s");
        String palabra9 = "n";
        System.out.println("n");
        String palabra10 = "d";
        System.out.println("d");
        String palabra11 = "y";
        System.out.println("y");
        String palabra12 = "medio";
        System.out.println("medio");
        String palabra13 = ",";
        System.out.println(",");
        
        //imprimir por consola la frase: "A cuesta le cuesta subir la cuesta y en 
        //medio de la cuesta, va y se acuesta"
        
        System.out.println(palabra4.toUpperCase() + " " + palabra1 + " " + palabra6 + palabra5 + " " + palabra1 + " " +
        palabra2 + " " + palabra3 + " " + palabra1 + " " + palabra11 + " " + palabra5 + palabra9 + " " + 
        palabra12 + " " + palabra10 + palabra5 + " " + palabra6 + palabra4 + " " + palabra1 + palabra13 +" " +
        palabra7 + palabra4 + " " + palabra11 + " " + palabra8 + palabra5 + " " + palabra1); 
        
                
        
        
        
        
        
        
        
        
        
        
    }
    
}
